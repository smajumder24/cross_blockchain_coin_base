#!/bin/sh

set -x

killall quorum
