#!/bin/sh

set -x

quorum --datadir data attach