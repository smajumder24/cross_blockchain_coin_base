#!/bin/sh

set -x

rm -rf data/geth data/raft-snap data/raft-wal data/quorum-raft-state
