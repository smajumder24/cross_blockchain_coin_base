#!/bin/sh

set -x

rm -rf data/geth data/history
