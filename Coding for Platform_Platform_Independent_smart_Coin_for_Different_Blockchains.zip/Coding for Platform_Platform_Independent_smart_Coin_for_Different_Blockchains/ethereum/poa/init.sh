#!/bin/sh

set -x

geth --datadir data init genesis.json