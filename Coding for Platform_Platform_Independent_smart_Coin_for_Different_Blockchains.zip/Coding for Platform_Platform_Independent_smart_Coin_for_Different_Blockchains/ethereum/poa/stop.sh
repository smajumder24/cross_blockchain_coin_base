#!/bin/sh

set -x

killall geth