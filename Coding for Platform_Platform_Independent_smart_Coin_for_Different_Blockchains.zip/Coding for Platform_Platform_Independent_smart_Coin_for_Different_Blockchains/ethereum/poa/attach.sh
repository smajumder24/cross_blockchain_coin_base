#!/bin/sh

set -x

geth --datadir data attach